import java.util.Scanner;

public class AnaliseCredito {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int score;
        double comprometimento;
        boolean inadimplente;

        System.out.print("Digite o Score: ");
        score = sc.nextInt();

        System.out.print("Comprometimento (%): ");
        comprometimento = sc.nextDouble();

        System.out.print("Inadimplente (true/false): ");
        inadimplente = sc.nextBoolean();

        if (inadimplente) {
            System.out.println("REPROVADO - Inadimplente");
        } else if (score < 400) {
            System.out.println("REPROVADO - Score baixo");
        } else if (score <= 700) {
            System.out.println("EM ANÁLISE");
        } else {
            if (comprometimento <= 30) {
                System.out.println("APROVADO");
            } else {
                System.out.println("REPROVADO - Alta dívida");
            }
        }

        sc.close();
    }
}
