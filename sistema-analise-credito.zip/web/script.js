function analisar() {
    let score = document.getElementById("score").value;
    let comp = document.getElementById("comp").value;
    let inad = document.getElementById("inad").value;

    let resultado = "";

    if (inad === "true") {
        resultado = "REPROVADO - Inadimplente";
    } else if (score < 400) {
        resultado = "REPROVADO - Score baixo";
    } else if (score <= 700) {
        resultado = "EM ANÁLISE";
    } else {
        if (comp <= 30) {
            resultado = "APROVADO";
        } else {
            resultado = "REPROVADO - Alta dívida";
        }
    }

    document.getElementById("resultado").innerText = resultado;
}
